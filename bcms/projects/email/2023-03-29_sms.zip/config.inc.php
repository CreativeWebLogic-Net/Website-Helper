<?php
	$ServerEmail="dan@i4u.com.au";
	$ServerURL="http://sms.i4u.com.au/";
	$ServerPath=$ServerURL;
?>