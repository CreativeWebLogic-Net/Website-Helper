<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 9px;
}

.style1 a{
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 9px;
	color: #0066CC;
}
.style2 {font-family: Arial, Helvetica, sans-serif}
.BBorder {
	border: thin solid #999999;
}
-->
</style></head>

<body>
<table width="100%"  border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td bgcolor="74899A"><h1>SMSMailPro</span></td>
  </tr>
  <tr>
    <td><span class="style2">[body]<br>
    <br>
    </span></td>
  </tr>
  <tr>
    <td bgcolor="#EBE8E7" class="BBorder"><p class="style1">To Log In Goto: <a href="http://smsmailpro.com">http://www.smsmailpro.com
    </a><br>
    <br>
	Support: <a href="mailto:info@smsmailpro.com">info@smsmailpro.com
    </a>
</p>    </td>
  </tr>
</table>
</body>
</html>
