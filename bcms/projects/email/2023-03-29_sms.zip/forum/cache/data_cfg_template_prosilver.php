<?php
$expired = (time() > 1243527858) ? true : false;
if ($expired) { return; }

$data = array (
  'name' => 'prosilver',
  'copyright' => '&copy; phpBB Group, 2007',
  'version' => '3.0.0',
  'template_bitfield' => 'lNg=',
  'filetime' => 1197486771,
);
?>