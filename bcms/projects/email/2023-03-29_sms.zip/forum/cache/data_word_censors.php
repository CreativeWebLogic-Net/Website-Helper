<?php
$expired = (time() > 1243527985) ? true : false;
if ($expired) { return; }

$data = array (
);
?>