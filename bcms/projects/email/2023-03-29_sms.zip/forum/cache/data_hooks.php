<?php
$expired = (time() > 1243517276) ? true : false;
if ($expired) { return; }

$data = array (
);
?>