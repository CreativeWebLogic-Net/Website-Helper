<?php
$expired = (time() > 1243527857) ? true : false;
if ($expired) { return; }

$data = array (
  'name' => 'prosilver',
  'copyright' => '&copy; phpBB Group, 2007',
  'version' => '3.0.0',
  'parse_css_file' => true,
  'filetime' => 1197486772,
);
?>