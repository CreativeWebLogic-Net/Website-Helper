<?php
$expired = (time() > 1243528226) ? true : false;
if ($expired) { return; }

$data = array (
  'special' => 
  array (
    1 => 
    array (
      'rank_title' => 'Site Admin',
      'rank_image' => '',
    ),
  ),
);
?>