<?php
  $connect["database.php"] = array('hostname'=>'db.smsmailpro.com','usernamedb'=>'smsg','passworddb'=>'smsg55','dbName'=>'smsg');
?>