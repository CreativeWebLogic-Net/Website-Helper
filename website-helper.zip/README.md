# iCWLNet_Full_Website_Builder
 The full install of our website builder.
 Multi-Database:-<br>
 <br>
 MySQL<br>
 PostgreSQL<br>
 Sqlite 3<br>
 <br>
 and coming soon:-<br>
 MongoDB<br>
 MS SQL Server Express<br>
 MS SQL Server 2019<br>
 Oracle<br>
 Google Cloud Big Query<br>
 Railway<br>
 jfrog<br>
 render pgSQL<br>


 Features:-
    Multi-Domain
    Multi-User
    Multiple Organizations
    Multi-Server
    Multi-Operating System
    Multi-Web-Control Panel
    Local Server
    Local Syncronized with remote
    Customizable Interface
    Customizable Templates
    News | Links | Assets | Pages 
    | Wiki | Web BBS | telnet BBS | Bug tracking |
    Features | Issues | Documentation | Project Management |
    Monitoring | Virus Scanning | Firewall Control | Browser Plugin |
    Versioning | Updates | Polls | Book Keeping | Accounting | Support Packages | Package Managers
    Projects | Source code | SVN Support | FAQs | Security | User / Server - Statistics | 
    Remote Storage / Backup
 
 
