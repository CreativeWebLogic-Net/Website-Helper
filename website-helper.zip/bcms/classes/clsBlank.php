<?php

    class clsBlank{
       
        function __construct(){
			
			
		}

        
    }

