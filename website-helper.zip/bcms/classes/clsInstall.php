<?php

    class clsInstall{
       
        function __construct(){
			
			
		}

        
    }

