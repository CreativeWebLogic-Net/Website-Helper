<?php 

define ("IMG", "1px.png"); // change this constant to use dif. image/path

//date_default_timezone_set("Australia/Brisbane");

class clsStats{

	

	function __construct(){

	}

	
	
		
		
		
	
	
}
