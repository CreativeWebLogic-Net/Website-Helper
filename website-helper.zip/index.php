<?php
  //print"FFF2233";
  include("bcms/classes/clsDebug.php");
  include("bcms/classes/clsRootVariables.php");
  include("bcms/classes/clsSystem.php");
  
  $s=new clsSystem();
  